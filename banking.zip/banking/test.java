/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Scanner;

/**
 *
 * @author ailing
 */
public class test {
private static String name;
   private static String idNum;
   private static int age;

   public static int getAge() {
      return age;
   }

   public static String getName() {
      return name;
   }

   public static String getIdNum() {
      return idNum;
   }

   public static void setAge( int newAge) {
      age = newAge;
   }

   public static void setName(String newName) {
      name = newName;
   }

   public static void setIdNum( String newId) {
      idNum = newId;
   }
}