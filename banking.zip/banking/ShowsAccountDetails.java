/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author ailing
 */
public class ShowsAccountDetails extends LoginAcc {

    private static final String ACCDETAILS = "./accDetails.txt";
    private static final String HISDEPOSIT = "./accDeposit.txt";
    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private static String accNo, userID;
    private static double accBal, deposit;

    public static void accountDetails() //public static void main(String args[])
    {

        BufferedReader br = null;
        FileReader fr = null;

        /*BufferedReader bw2 = null;
         FileReader fw2 = null;*/
        String line;
        int option;
  
        Scanner input = new Scanner(System.in);
        AccountDetails encap = new AccountDetails();

        try {
            fr = new FileReader(ACCDETAILS);
            br = new BufferedReader(fr);

            userID = CustomerDetails.getUserID();
            while ((line = br.readLine()) != null) {
                if (line.contains(userID)) {

                    System.out.println(line);

                    String[] data = line.split(" ");
                    
                     accNo = data[4];
                    //System.out.println(accNo + " ");
                   encap.setAccNo(accNo);
                   
                    // System.out.println(data[7]+" ");
                    accBal = Double.parseDouble(data[7]);
                    encap.setAccStart(accBal);
                    
                   
                   
                  

                }

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }

                if (fr != null) {
                    fr.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }

   

}
