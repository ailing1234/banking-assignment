/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;

/**
 *
 * @author ong
 */
public class LoginAcc extends Menu {

    private static final String LOGINFILE = "./loginfile.txt";
    private static String userID, password;

    public static void login() {

        BufferedReader br = null;
        FileReader fr = null;

        String line;
        int option;

        CustomerDetails encap = new CustomerDetails();
        Scanner input = new Scanner(System.in);

        try {

            fr = new FileReader(LOGINFILE);
            br = new BufferedReader(fr);
            Scanner input2 = new Scanner(fr);
            System.out.println("Login to your account:");
            System.out.print("UserID: ");
            userID = input.next();
            encap.setUserID(userID);

            System.out.print("Password: ");
            password = input.next();

            while ((line = br.readLine()) != null) {
                
                    if (line.contains(userID)) {
                        if (line.endsWith(password)){
                        System.out.println(userID + "," + "Welcome to OK Bank");
                        MenuLogin menu = new MenuLogin();
                        menu.menuLogin();

                    } else {
                        System.out.println("Please enter the correct user id or password.");
                        login();
                    }
                    }

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                if (br != null) {
                    br.close();
                }

                if (fr != null) {
                    fr.close();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }
}
