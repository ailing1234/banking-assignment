/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.util.Scanner;

/**
 *
 * @author ailing
 */
public class test2 {

    public static void main(String args[]) {

        test encap = new test();

        String accNo;
        Scanner input = new Scanner(System.in);
        String line = "UserId: 1 Account Number: 1 Account Balance: 3.00";
        System.out.println(line);

        String[] data = line.split(" ");
                    // System.out.println(data[7]+" ");

        accNo = data[4];
        System.out.println(accNo + " ");
         encap.setName(accNo);

        //System.out.println("Name : " + encap.getName());
        test3.main(args);
    }
}
     
     /*test encap = new test();
      
       Scanner input = new Scanner(System.in);
      
      System.out.println("Login to your account:");
      System.out.print("UserID: ");
      String userID = input.next();
      
      encap.setName(userID);
     

      //System.out.println("Name : " + encap.getName());
      test3.main(args);
   }
}*/
