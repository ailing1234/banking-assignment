/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.util.Scanner;

/**
 *
 * @author ailing
 */
public class MenuLogin {

    private static String userID, password;

    public static void menuLogin() {

        String line;
        int option;
        Scanner input = new Scanner(System.in);

        System.out.println("------------------");
        System.out.println("1. View account details.");
        System.out.println("2. Deposit.");
        System.out.println("3. Withdraw.");
        System.out.println("4. Transaction.");
        System.out.println("5. History.");
        System.out.println("6. Exit.");

        System.out.print("Please select your option: ");
        option = input.nextInt();
        userID = CustomerDetails.getUserID();
        try {

            if (option == 1) {
                //view account details
                System.out.println(userID + "," + "Welcome to OK Bank");
                ShowsAccountDetails.accountDetails();
                MenuLogin.menuLogin();
            } else if (option == 2) {
                //deposit
                System.out.println(userID + "," + "Welcome to OK Bank");
                Deposit.deposit();
                MenuLogin.menuLogin();

            } else if (option == 3) {
                //withdraw

            } else if (option == 4) {
                //transaction
            } else if (option == 5) {
                //History
            } else if (option == 6) {
                System.exit(0);
            } else {
                System.out.println("Please enter correct option.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
