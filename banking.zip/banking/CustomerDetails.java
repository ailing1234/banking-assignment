/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

/**
 *
 * @author ailing
 */
public class CustomerDetails {
     private static String userID;
    
    
    public static String getUserID(){
       
        return userID;
    }
    
    public static void setUserID(String userID1){
        userID = userID1;
    }
}
