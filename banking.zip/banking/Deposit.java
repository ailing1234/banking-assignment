/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 *
 * @author ailing
 */
public class Deposit {

    private static final String ACCDETAILS = "./accDetails.txt";
    private static final String HISDEPOSIT = "./accDeposit.txt";
    private static DecimalFormat df2 = new DecimalFormat("#.##");
    private static String accNo, userID, date;
    private static double accBal, deposit;

    public static void deposit() {

        BufferedWriter bw = null;
        FileWriter fw = null;

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        date = dtf.format(now);
        AccountDetails.setDate(date);

        try {
            Scanner input = new Scanner(System.in);
            System.out.print("How much you want to deposit in your saving account? ");
            deposit = input.nextDouble();
            input.nextLine();
            AccountDetails.setDeposit(deposit);

            File file = new File(ACCDETAILS);

            // if file doesnt exists, then create it
            if (!file.exists()) {
                file.createNewFile();
            }

            // true = append file
            /*fw = new FileWriter(file.getAbsoluteFile(), true);
             bw = new BufferedWriter(fw);

             bw.write("Account No: " + AccountDetails.getAccNo());
             bw.write("Date: " + AccountDetails.getDate());
             bw.write("Deposit: " + df2.format(deposit));
             bw.write("Balance: " + df2.format(accBal));
             bw.newLine();*/
            System.out.println(AccountDetails.getAccNo());
            System.out.println(AccountDetails.getDate());
            System.out.println(AccountDetails.getAccStart());
            System.out.println(AccountDetails.getDeposit());
            System.out.println(AccountDetails.getAfterDeposit());
            // System.out.print(accBal);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }
}
