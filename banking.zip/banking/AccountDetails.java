/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package banking;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author ailing
 */
public class AccountDetails {

    private static String accNo;
    private static String date;
    private static double accStart, accDeposit, accAfterDeposit;

    //Account
    public static String getAccNo() {

        return accNo;
    }

    public static void setAccNo(String accNo1) {
        accNo = accNo1;
    }

    //Start value
    public static Double getAccStart() {

        return accStart;
    }

    public static void setAccStart(Double accStart1) {
        accStart = accStart1;
    }

    //Deposit
    public static Double getDeposit() {

        return accDeposit;
    }

    public static void setDeposit(Double accDeposit1) {
        accDeposit = accDeposit1;
    }

    //balance
    public static Double getAfterDeposit() {

        return accAfterDeposit;
    }

    public static void setAfterDeposit(Double accAfterDeposit1) {

        accAfterDeposit = AccountDetails.accStart + accDeposit;
        accAfterDeposit = accAfterDeposit1;

    }

    //date
    public static String getDate() {

        return date;
    }

    public static void setDate(String date1) {

        date = date1;
    }

}
